package com.simplelogintutorial;

/**
 *
 * @author Jiro Mendador
 */
public class SimpleLoginTutorial {

    public static void main(String[] args) {
        //in the main method we will call our LoginGui Class 
        LoginGui login = new LoginGui();
        login.setLoginGuiProperties();
    }
}
